package com.pointdown.app.data

data class IssueItem(
    val key: String,
    val summary: String?,
    val sp: Double,
    val browseUrl: String,
    var newSp: Double = sp,
    var dirty: Boolean = false,
    val isSpecial: Boolean = false
)
