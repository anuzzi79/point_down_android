package com.pointdown.app.ui

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.pointdown.app.R
import com.pointdown.app.data.IssueItem
import kotlin.math.round

class IssueAdapter(
    private val items: MutableList<IssueItem>,
    private val onDirtyChanged: () -> Unit
) : RecyclerView.Adapter<IssueAdapter.Holder>() {

    inner class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val keyText: TextView = v.findViewById(R.id.keyText)
        val summaryText: TextView = v.findViewById(R.id.summaryText)
        val spEdit: EditText = v.findViewById(R.id.spEdit)
        val downBtn: Button = v.findViewById(R.id.downBtn)
        val upBtn: Button = v.findViewById(R.id.upBtn)
        val openBtn: Button = v.findViewById(R.id.openBtn)
        val dirtyText: TextView = v.findViewById(R.id.dirtyText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_issue, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(h: Holder, pos: Int) {
        val it = items[pos]
        h.keyText.text = it.key
        h.summaryText.text = it.summary ?: "(sem resumo)"
        h.spEdit.setText(it.newSp.toString())

        fun setDirty(d: Boolean) {
            it.dirty = d
            h.dirtyText.visibility = if (d) View.VISIBLE else View.GONE
            onDirtyChanged()
        }

        fun clampHalf(v: Double): Double {
            val rounded = (round(v * 2.0) / 2.0)
            return if (rounded < 0.0) 0.0 else rounded
        }

        h.downBtn.setOnClickListener {
            val cur = h.spEdit.text.toString().toDoubleOrNull() ?: it.newSp
            val nv = clampHalf(cur - 0.5)
            it.newSp = nv
            h.spEdit.setText(nv.toString())
            setDirty(true)
        }
        h.upBtn.setOnClickListener {
            val cur = h.spEdit.text.toString().toDoubleOrNull() ?: it.newSp
            val nv = clampHalf(cur + 0.5)
            it.newSp = nv
            h.spEdit.setText(nv.toString())
            setDirty(true)
        }
        h.spEdit.setOnFocusChangeListener { _, has ->
            if (!has) {
                val v = h.spEdit.text.toString().toDoubleOrNull()
                if (v != null) {
                    val nv = clampHalf(v)
                    if (nv != it.newSp) {
                        it.newSp = nv
                        h.spEdit.setText(nv.toString())
                        setDirty(true)
                    }
                }
            }
        }
        h.openBtn.setOnClickListener { v ->
            v.context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.browseUrl)))
        }
        h.dirtyText.visibility = if (it.dirty) View.VISIBLE else View.GONE
    }

    override fun getItemCount(): Int = items.size

    fun setData(newItems: List<IssueItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
