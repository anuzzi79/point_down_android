package com.pointdown.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pointdown.app.alarm.AlarmScheduler
import com.pointdown.app.data.IssueItem
import com.pointdown.app.data.JiraClient
import com.pointdown.app.data.Prefs
import com.pointdown.app.ui.IssueAdapter
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

class MainActivity : AppCompatActivity(), CoroutineScope {
    private lateinit var statusText: TextView
    private lateinit var recyclerMain: RecyclerView
    private lateinit var recyclerSpecial: RecyclerView
    private lateinit var specialTitle: TextView

    private val job = SupervisorJob()
    override val coroutineContext: CoroutineContext = Dispatchers.Main + job

    private var adapterMain: IssueAdapter? = null
    private var adapterSpecial: IssueAdapter? = null

    private var jira: JiraClient? = null
    private var itemsMain = mutableListOf<IssueItem>()
    private var itemsSpecial = mutableListOf<IssueItem>()

    private val notifPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById(R.id.toolbar))

        statusText = findViewById(R.id.statusText)
        recyclerMain = findViewById(R.id.recyclerMain)
        recyclerSpecial = findViewById(R.id.recyclerSpecial)
        specialTitle = findViewById(R.id.specialTitle)

        recyclerMain.layoutManager = LinearLayoutManager(this)
        recyclerSpecial.layoutManager = LinearLayoutManager(this)

        adapterMain = IssueAdapter(itemsMain) { }
        adapterSpecial = IssueAdapter(itemsSpecial) { }

        recyclerMain.adapter = adapterMain
        recyclerSpecial.adapter = adapterSpecial

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        loadData()
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId) {
            R.id.action_refresh -> { loadData(); true }
            R.id.action_save -> { saveChanges(); true }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setStatus(msg: String) {
        statusText.text = msg
    }

    private fun loadData() {
        val prefs = Prefs(this)
        if (!prefs.isConfigured()) {
            setStatus("Configura Base URL / Email / Token em Settings.")
            return
        }

        setStatus(getString(R.string.status_loading))
        val (h,m) = prefs.getHourMinute()
        AlarmScheduler.scheduleDaily(this, h, m)

        jira = JiraClient(prefs.baseUrl!!, prefs.email!!, prefs.token!!)
        val jql = prefs.jql

        launch {
            try {
                val (main, special) = withContext(Dispatchers.IO) {
                    val main = jira!!.fetchCurrentSprintIssues(jql)
                    val spec = jira!!.fetchSpecialSprintIssues()
                    Pair(main, spec.filter { s -> main.none { it.key == s.key } })
                }
                itemsMain.clear(); itemsMain.addAll(main)
                itemsSpecial.clear(); itemsSpecial.addAll(special)
                adapterMain?.setData(itemsMain)
                if (itemsSpecial.isNotEmpty()) {
                    specialTitle.visibility = View.VISIBLE
                    recyclerSpecial.visibility = View.VISIBLE
                    adapterSpecial?.setData(itemsSpecial)
                } else {
                    specialTitle.visibility = View.GONE
                    recyclerSpecial.visibility = View.GONE
                }
                setStatus("Pronto. ${itemsMain.size} cards.")
            } catch (e: Exception) {
                setStatus("❌ ${e.message}")
            }
        }
    }

    private fun saveChanges() {
        val toSave = (itemsMain + itemsSpecial).filter { it.dirty && it.newSp != it.sp }
        if (toSave.isEmpty()) {
            setStatus("Nada para salvar.")
            return
        }
        setStatus("Salvando alterações…")
        launch {
            try {
                withContext(Dispatchers.IO) {
                    toSave.forEach { jira!!.updateStoryPoints(it.key, it.newSp) }
                }
                toSave.forEach { it.sp = it.newSp; it.dirty = false }
                adapterMain?.notifyDataSetChanged()
                adapterSpecial?.notifyDataSetChanged()
                setStatus("✅ ${toSave.size} issue(s) atualizadas.")
            } catch (e: Exception) {
                setStatus("❌ Erro ao salvar: ${e.message}")
            }
        }
    }
}
